const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET === "change-this-to-a-long-random-secret") {
  console.warn(
    "⚠️  هشدار امنیتی: JWT_SECRET تنظیم نشده یا مقدار پیش‌فرضه. حتماً یک رشته‌ی تصادفی و محرمانه در .env بذارید."
  );
}

function signToken(staff) {
  return jwt.sign(
    { id: staff.id, username: staff.username, role: staff.role },
    JWT_SECRET || "insecure-dev-secret",
    { expiresIn: "12h" }
  );
}

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.staff_token;
  if (!token) return res.status(401).json({ error: "لازمه وارد بشید" });
  try {
    req.staff = jwt.verify(token, JWT_SECRET || "insecure-dev-secret");
    next();
  } catch (e) {
    return res.status(401).json({ error: "نشست شما منقضی شده، دوباره وارد بشید" });
  }
}

function requireAdmin(req, res, next) {
  if (!req.staff || req.staff.role !== "admin") {
    return res.status(403).json({ error: "فقط مدیر به این بخش دسترسی داره" });
  }
  next();
}

module.exports = { signToken, requireAuth, requireAdmin };
