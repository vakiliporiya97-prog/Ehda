function effectiveGapHours(donor, settings) {
  return (donor.overrides && donor.overrides.minGapHours) || settings.minGapHours;
}
function effectiveRescreenMonths(donor, settings) {
  return (donor.overrides && donor.overrides.rescreenMonths) || settings.rescreenMonths;
}

function isClosedDay(date, settings) {
  return settings.closedWeekdays.includes(new Date(date).getDay());
}

function nextOpenDate(date, settings) {
  const d = new Date(date);
  while (isClosedDay(d, settings)) d.setDate(d.getDate() + 1);
  return d;
}

function donationVisits(donor) {
  return donor.visits
    .filter((v) => v.type === "donation")
    .sort((a, b) => new Date(b.date) - new Date(a.date));
}
function screeningVisits(donor) {
  return donor.visits
    .filter((v) => v.type === "screening")
    .sort((a, b) => new Date(b.date) - new Date(a.date));
}
function lastDonation(donor) {
  return donationVisits(donor)[0] || null;
}
function lastScreening(donor) {
  return screeningVisits(donor)[0] || null;
}

function monthsBetween(a, b) {
  const d1 = new Date(a), d2 = new Date(b);
  return (d2.getFullYear() - d1.getFullYear()) * 12 + (d2.getMonth() - d1.getMonth());
}

/** آیا نمونه‌ی غربالگری این فرد هنوز معتبره (کمتر از مدت تعیین‌شده از آخرین نمونه گذشته)؟ */
function isScreeningValid(donor, settings, now = new Date()) {
  const last = lastScreening(donor);
  if (!last) return false;
  return monthsBetween(last.date, now) < effectiveRescreenMonths(donor, settings);
}

/** تاریخ بعدی که فرد مجاز به اهداست؛ null یعنی همین الان مجازه (به‌جز روزهای تعطیل) */
function nextEligibleDate(donor, settings, now = new Date()) {
  const last = lastDonation(donor);
  let base = null;
  if (last) {
    base = new Date(new Date(last.date).getTime() + effectiveGapHours(donor, settings) * 3600 * 1000);
  }
  if (!base) {
    return isClosedDay(now, settings) ? nextOpenDate(now, settings) : null;
  }
  return nextOpenDate(base, settings);
}

function isEligibleNow(donor, settings, now = new Date()) {
  if (donor.status !== "approved") return false;
  if (!isScreeningValid(donor, settings, now)) return false;
  const next = nextEligibleDate(donor, settings, now);
  return !next || next <= now;
}

function pendingFollowUp(donor, now = new Date()) {
  const last = lastDonation(donor);
  if (!last || last.followUp) return null;
  const hours = (now - new Date(last.date)) / 3600000;
  return hours >= 20 ? last : null;
}

function donorFlagged(donor) {
  return donor.visits.some(
    (v) => (v.immediateCheck && v.immediateCheck.concerning) || (v.followUp && v.followUp.concerning)
  );
}

module.exports = {
  isClosedDay, nextOpenDate, donationVisits, screeningVisits, lastDonation, lastScreening,
  monthsBetween, isScreeningValid, nextEligibleDate, isEligibleNow, pendingFollowUp, donorFlagged,
  effectiveGapHours, effectiveRescreenMonths,
};
