const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

function defaultData() {
  return {
    settings: {
      minGapHours: 240,       // فاصله‌ی مجاز بین دو اهدا (پیش‌فرض ۱۰ روز = ۲۴۰ ساعت)
      rescreenMonths: 6,      // اعتبار نمونه‌گیری اولیه (پیش‌فرض ۶ ماه)
      labWaitMinDays: 7,      // حداقل زمان انتظار نتیجه‌ی نمونه تا تایید
      labWaitMaxDays: 10,     // حداکثر زمان انتظار نتیجه‌ی نمونه تا تایید
      closedWeekdays: [4, 5], // ۰=یکشنبه ... ۴=پنجشنبه، ۵=جمعه (پیش‌فرض: تعطیلی پنجشنبه و جمعه)
      centerName: "مرکز اهدا پلاسما نوین پلاسما پورا دارو",
    },
    staff: [],   // {id, username, passwordHash, role, mustChangePassword, createdAt}
    donors: [],  // {id, phone, name, status, screeningDate, overrides:{minGapHours,rescreenMonths}, visits:[], createdAt}
    messages: [], // {id, donorId, body, appointmentDate, createdByUsername, createdAt, readAt}
    nextIds: { staff: 1, donor: 1, message: 1, visit: 1 },
  };
}

function ensureDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData(), null, 2), "utf8");
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_FILE, "utf8");
  return JSON.parse(raw);
}

function writeDb(data) {
  // نوشتن اتمیک: اول در یک فایل موقت، بعد جایگزینی — تا در صورت قطع ناگهانی برنامه، فایل دیتابیس خراب نشه
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, DB_FILE);
}

/** اجرای یک تابع تغییر روی دیتابیس و ذخیره‌ی خودکار نتیجه؛ برای جلوگیری از رقابت هم‌زمان روی نوشتن استفاده می‌شه */
function mutate(fn) {
  const db = readDb();
  const result = fn(db);
  writeDb(db);
  return result;
}

module.exports = { readDb, writeDb, mutate, ensureDb, DATA_DIR, DB_FILE };
