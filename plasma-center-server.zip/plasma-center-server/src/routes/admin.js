const express = require("express");
const bcrypt = require("bcryptjs");
const { mutate, readDb } = require("../db");
const domain = require("../domain");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth); // همه‌ی مسیرهای این فایل فقط برای کارکنانِ واردشده

function donorAdminView(donor, settings) {
  const now = new Date();
  return {
    ...donor,
    eligibleNow: domain.isEligibleNow(donor, settings, now),
    nextEligibleDate: domain.nextEligibleDate(donor, settings, now),
    screeningValid: domain.isScreeningValid(donor, settings, now),
    pendingFollowUp: domain.pendingFollowUp(donor, now),
    flagged: domain.donorFlagged(donor),
  };
}

/* ---------- تنظیمات کلی مرکز ---------- */
router.get("/settings", (req, res) => {
  const db = readDb();
  res.json(db.settings);
});

router.put("/settings", requireAdmin, (req, res) => {
  const { minGapHours, rescreenMonths, labWaitMinDays, labWaitMaxDays, closedWeekdays, centerName } = req.body || {};
  const result = mutate((db) => {
    if (minGapHours) db.settings.minGapHours = Number(minGapHours);
    if (rescreenMonths) db.settings.rescreenMonths = Number(rescreenMonths);
    if (labWaitMinDays) db.settings.labWaitMinDays = Number(labWaitMinDays);
    if (labWaitMaxDays) db.settings.labWaitMaxDays = Number(labWaitMaxDays);
    if (Array.isArray(closedWeekdays)) db.settings.closedWeekdays = closedWeekdays.map(Number);
    if (centerName) db.settings.centerName = String(centerName);
    return db.settings;
  });
  res.json(result);
});

/* ---------- اهداکنندگان ---------- */
router.get("/donors", (req, res) => {
  const db = readDb();
  res.json(db.donors.map((d) => donorAdminView(d, db.settings)));
});

router.get("/donors/:phone", (req, res) => {
  const db = readDb();
  const donor = db.donors.find((d) => d.phone === req.params.phone);
  if (!donor) return res.status(404).json({ error: "پیدا نشد" });
  res.json(donorAdminView(donor, db.settings));
});

router.post("/donors/:phone/approve", (req, res) => {
  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === req.params.phone);
    if (!donor) return { error: "پیدا نشد" };
    donor.status = "approved";
    return { donor };
  });
  if (result.error) return res.status(404).json(result);
  const db = readDb();
  res.json(donorAdminView(result.donor, db.settings));
});

router.put("/donors/:phone/overrides", requireAdmin, (req, res) => {
  const { minGapHours, rescreenMonths } = req.body || {};
  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === req.params.phone);
    if (!donor) return { error: "پیدا نشد" };
    donor.overrides = {
      minGapHours: minGapHours ? Number(minGapHours) : null,
      rescreenMonths: rescreenMonths ? Number(rescreenMonths) : null,
    };
    return { donor };
  });
  if (result.error) return res.status(404).json(result);
  const db = readDb();
  res.json(donorAdminView(result.donor, db.settings));
});

/* ---------- پیام و تعیین نوبت ---------- */
router.post("/donors/:phone/messages", (req, res) => {
  const { body, appointmentDate } = req.body || {};
  if (!body || !body.trim()) return res.status(400).json({ error: "متن پیام خالیه" });

  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === req.params.phone);
    if (!donor) return { error: "پیدا نشد" };
    const message = {
      id: db.nextIds.message++,
      donorId: donor.id,
      body: body.trim(),
      appointmentDate: appointmentDate || null,
      createdByUsername: req.staff.username,
      createdAt: new Date().toISOString(),
      readAt: null,
    };
    db.messages.push(message);
    return { message };
  });
  if (result.error) return res.status(404).json(result);
  res.status(201).json(result.message);
});

router.get("/donors/:phone/messages", (req, res) => {
  const db = readDb();
  const donor = db.donors.find((d) => d.phone === req.params.phone);
  if (!donor) return res.status(404).json({ error: "پیدا نشد" });
  const messages = db.messages
    .filter((m) => m.donorId === donor.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(messages);
});

/* ---------- مدیریت کاربران کارکنان (فقط مدیر) ---------- */
router.get("/staff", requireAdmin, (req, res) => {
  const db = readDb();
  res.json(db.staff.map((s) => ({ id: s.id, username: s.username, role: s.role, createdAt: s.createdAt })));
});

router.post("/staff", requireAdmin, (req, res) => {
  const { username, password, role } = req.body || {};
  if (!username || !password || password.length < 8) {
    return res.status(400).json({ error: "نام کاربری لازمه و رمز باید حداقل ۸ کاراکتر باشه" });
  }
  const result = mutate((db) => {
    if (db.staff.find((s) => s.username === username)) return { error: "این نام کاربری قبلاً وجود داره" };
    const staff = {
      id: db.nextIds.staff++,
      username,
      passwordHash: bcrypt.hashSync(password, 12),
      role: role === "admin" ? "admin" : "staff",
      mustChangePassword: true,
      createdAt: new Date().toISOString(),
    };
    db.staff.push(staff);
    return { staff };
  });
  if (result.error) return res.status(409).json(result);
  res.status(201).json({ id: result.staff.id, username: result.staff.username, role: result.staff.role });
});

router.delete("/staff/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (id === req.staff.id) return res.status(400).json({ error: "نمی‌تونید حساب خودتون رو حذف کنید" });
  const result = mutate((db) => {
    const before = db.staff.length;
    db.staff = db.staff.filter((s) => s.id !== id);
    if (db.staff.length === before) return { error: "پیدا نشد" };
    return { ok: true };
  });
  if (result.error) return res.status(404).json(result);
  res.json(result);
});

module.exports = router;
