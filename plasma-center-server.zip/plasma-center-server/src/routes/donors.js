const express = require("express");
const { mutate, readDb } = require("../db");
const domain = require("../domain");

const router = express.Router();

function normalizePhone(p) {
  return String(p || "").replace(/[^0-9]/g, "");
}

function donorPublicView(donor, settings) {
  const now = new Date();
  return {
    phone: donor.phone,
    name: donor.name,
    status: donor.status,
    screeningDate: donor.screeningDate || null,
    createdAt: donor.createdAt,
    visits: donor.visits,
    eligibleNow: domain.isEligibleNow(donor, settings, now),
    nextEligibleDate: domain.nextEligibleDate(donor, settings, now),
    screeningValid: domain.isScreeningValid(donor, settings, now),
    pendingFollowUp: domain.pendingFollowUp(donor, now),
    needsRescreen: donor.status === "approved" && !domain.isScreeningValid(donor, settings, now),
  };
}

router.get("/settings/public", (req, res) => {
  const db = readDb();
  const s = db.settings;
  res.json({
    centerName: s.centerName,
    minGapHours: s.minGapHours,
    rescreenMonths: s.rescreenMonths,
    labWaitMinDays: s.labWaitMinDays,
    labWaitMaxDays: s.labWaitMaxDays,
    closedWeekdays: s.closedWeekdays,
  });
});

router.post("/register", (req, res) => {
  const phone = normalizePhone(req.body && req.body.phone);
  const name = String((req.body && req.body.name) || "").trim();
  if (phone.length < 10) return res.status(400).json({ error: "شماره موبایل معتبر نیست" });
  if (name.length < 2) return res.status(400).json({ error: "نام معتبر نیست" });

  const result = mutate((db) => {
    if (db.donors.find((d) => d.phone === phone)) {
      return { error: "این شماره قبلاً ثبت شده — از همون شماره وارد بشید", code: "exists" };
    }
    const donor = {
      id: db.nextIds.donor++,
      phone,
      name,
      status: "new",
      screeningDate: null,
      overrides: {},
      visits: [],
      createdAt: new Date().toISOString(),
    };
    db.donors.push(donor);
    return { donor };
  });

  if (result.error) return res.status(409).json(result);
  const db = readDb();
  res.status(201).json(donorPublicView(result.donor, db.settings));
});

router.get("/:phone", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const db = readDb();
  const donor = db.donors.find((d) => d.phone === phone);
  if (!donor) return res.status(404).json({ error: "پرونده‌ای با این شماره پیدا نشد" });
  res.json(donorPublicView(donor, db.settings));
});

router.get("/:phone/messages", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const db = readDb();
  const donor = db.donors.find((d) => d.phone === phone);
  if (!donor) return res.status(404).json({ error: "پرونده‌ای با این شماره پیدا نشد" });
  const messages = db.messages
    .filter((m) => m.donorId === donor.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(messages);
});

router.post("/:phone/visits", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const type = req.body && req.body.type;
  if (!["screening", "donation"].includes(type)) return res.status(400).json({ error: "نوع ویزیت نامعتبره" });

  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === phone);
    if (!donor) return { error: "پرونده پیدا نشد" };

    const hasScreening = donor.visits.some((v) => v.type === "screening");
    if (!hasScreening && type !== "screening") {
      return { error: "اول باید ویزیت غربالگری ثبت بشه" };
    }
    if (type === "donation") {
      const now = new Date();
      if (!domain.isEligibleNow(donor, db.settings, now)) {
        return { error: "در حال حاضر مجاز به ثبت اهدا نیستید" };
      }
    }

    const visit = {
      id: db.nextIds.visit++,
      type,
      date: new Date().toISOString(),
      survey: null,
      immediateCheck: type === "donation" ? null : undefined,
      followUp: null,
    };
    donor.visits.unshift(visit);
    return { donor, visit };
  });

  if (result.error) return res.status(400).json(result);
  const db = readDb();
  res.status(201).json({ visit: result.visit, donor: donorPublicView(result.donor, db.settings) });
});

router.post("/:phone/visits/:visitId/survey", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const visitId = Number(req.params.visitId);
  const answers = req.body || {};

  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === phone);
    if (!donor) return { error: "پرونده پیدا نشد" };
    const visit = donor.visits.find((v) => v.id === visitId);
    if (!visit) return { error: "ویزیت پیدا نشد" };

    visit.survey = { ...answers, completedAt: new Date().toISOString() };

    if (visit.type === "screening" && donor.status === "new") {
      donor.status = "awaiting_approval";
      donor.screeningDate = visit.date;
    } else if (visit.type === "screening" && donor.status === "approved") {
      // نمونه‌گیری مجدد بعد از انقضای اعتبار — دوباره نیاز به تایید مدیر داره
      donor.status = "awaiting_approval";
      donor.screeningDate = visit.date;
    }
    return { donor, visit };
  });

  if (result.error) return res.status(400).json(result);
  const db = readDb();
  res.json({ visit: result.visit, donor: donorPublicView(result.donor, db.settings) });
});

router.post("/:phone/visits/:visitId/immediate-check", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const visitId = Number(req.params.visitId);
  const { symptoms, feeling } = req.body || {};
  if (!Array.isArray(symptoms) || !feeling) return res.status(400).json({ error: "پاسخ‌ها ناقصه" });

  const concerning = symptoms.some((s) => s !== "هیچ‌کدام") || feeling === "ضعیف";

  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === phone);
    if (!donor) return { error: "پرونده پیدا نشد" };
    const visit = donor.visits.find((v) => v.id === visitId);
    if (!visit) return { error: "ویزیت پیدا نشد" };
    visit.immediateCheck = { symptoms, feeling, concerning, completedAt: new Date().toISOString() };
    return { donor, visit };
  });

  if (result.error) return res.status(400).json(result);
  const db = readDb();
  res.json({ visit: result.visit, donor: donorPublicView(result.donor, db.settings) });
});

router.post("/:phone/visits/:visitId/follow-up", (req, res) => {
  const phone = normalizePhone(req.params.phone);
  const visitId = Number(req.params.visitId);
  const { symptoms, feeling } = req.body || {};
  if (!Array.isArray(symptoms) || !feeling) return res.status(400).json({ error: "پاسخ‌ها ناقصه" });

  const concerning = symptoms.some((s) => s !== "هیچ‌کدام") || feeling === "ضعیف";

  const result = mutate((db) => {
    const donor = db.donors.find((d) => d.phone === phone);
    if (!donor) return { error: "پرونده پیدا نشد" };
    const visit = donor.visits.find((v) => v.id === visitId);
    if (!visit) return { error: "ویزیت پیدا نشد" };
    visit.followUp = { symptoms, feeling, concerning, completedAt: new Date().toISOString() };
    return { donor, visit };
  });

  if (result.error) return res.status(400).json(result);
  const db = readDb();
  res.json({ visit: result.visit, donor: donorPublicView(result.donor, db.settings) });
});

module.exports = router;
