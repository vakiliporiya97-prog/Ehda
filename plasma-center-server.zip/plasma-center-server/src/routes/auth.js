const express = require("express");
const bcrypt = require("bcryptjs");
const { mutate, readDb } = require("../db");
const { signToken, requireAuth } = require("../middleware/auth");

const router = express.Router();

const isProd = process.env.NODE_ENV === "production";
const cookieOpts = {
  httpOnly: true,
  sameSite: "lax",
  secure: isProd, // در حالت production (پشت HTTPS) کوکی فقط روی https ارسال می‌شه
  maxAge: 12 * 60 * 60 * 1000,
};

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "نام کاربری و رمز عبور لازمه" });

  const db = readDb();
  const staff = db.staff.find((s) => s.username === username);
  if (!staff || !bcrypt.compareSync(password, staff.passwordHash)) {
    return res.status(401).json({ error: "نام کاربری یا رمز عبور اشتباهه" });
  }

  const token = signToken(staff);
  res.cookie("staff_token", token, cookieOpts);
  res.json({
    id: staff.id,
    username: staff.username,
    role: staff.role,
    mustChangePassword: !!staff.mustChangePassword,
  });
});

router.post("/logout", (req, res) => {
  res.clearCookie("staff_token");
  res.json({ ok: true });
});

router.get("/me", requireAuth, (req, res) => {
  const db = readDb();
  const staff = db.staff.find((s) => s.id === req.staff.id);
  if (!staff) return res.status(401).json({ error: "کاربر یافت نشد" });
  res.json({ id: staff.id, username: staff.username, role: staff.role, mustChangePassword: !!staff.mustChangePassword });
});

router.post("/change-password", requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: "رمز جدید باید حداقل ۸ کاراکتر باشه" });
  }
  const result = mutate((db) => {
    const staff = db.staff.find((s) => s.id === req.staff.id);
    if (!staff) return { error: "کاربر یافت نشد" };
    if (!bcrypt.compareSync(currentPassword || "", staff.passwordHash)) {
      return { error: "رمز فعلی اشتباهه" };
    }
    staff.passwordHash = bcrypt.hashSync(newPassword, 12);
    staff.mustChangePassword = false;
    return { ok: true };
  });
  if (result.error) return res.status(400).json(result);
  res.json(result);
});

module.exports = router;
