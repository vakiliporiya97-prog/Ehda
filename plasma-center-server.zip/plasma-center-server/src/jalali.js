/**
 * تبدیل تاریخ میلادی به شمسی (جلالی) بدون نیاز به پکیج خارجی.
 * پیاده‌سازی الگوریتم استاندارد تقویم جلالی (بر پایه‌ی فرمول‌های نجومی عمومی).
 */

const PERSIAN_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];
const PERSIAN_WEEKDAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

function div(a, b) {
  return Math.floor(a / b);
}

function gregorianToJalali(gy, gm, gd) {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let gy2 = gm > 2 ? gy + 1 : gy;
  let days =
    355666 +
    365 * gy +
    div(gy2 + 3, 4) -
    div(gy2 + 99, 100) +
    div(gy2 + 399, 400) +
    gd +
    g_d_m[gm - 1];
  let jy = -1595 + 33 * div(days, 12053);
  days %= 12053;
  jy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    jy += div(days - 1, 365);
    days = (days - 1) % 365;
  }
  let jm, jd;
  if (days < 186) {
    jm = 1 + div(days, 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + div(days - 186, 30);
    jd = 1 + ((days - 186) % 30);
  }
  return [jy, jm, jd];
}

/** ورودی: Date شیء جاوااسکریپت یا رشته‌ی ISO. خروجی: {year, month, day, monthName, weekday} */
function toJalali(dateInput) {
  const d = new Date(dateInput);
  const [jy, jm, jd] = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return {
    year: jy,
    month: jm,
    day: jd,
    monthName: PERSIAN_MONTHS[jm - 1],
    weekday: PERSIAN_WEEKDAYS[d.getDay()],
  };
}

function toPersianDigits(input) {
  const map = { 0: "۰", 1: "۱", 2: "۲", 3: "۳", 4: "۴", 5: "۵", 6: "۶", 7: "۷", 8: "۸", 9: "۹" };
  return String(input).replace(/[0-9]/g, (c) => map[c]);
}

/** تاریخ کامل مثل «سه‌شنبه ۱۹ تیر ۱۴۰۵» */
function formatJalaliFull(dateInput) {
  const j = toJalali(dateInput);
  return `${j.weekday} ${toPersianDigits(j.day)} ${j.monthName} ${toPersianDigits(j.year)}`;
}

/** تاریخ کوتاه مثل «۱۹ تیر ۱۴۰۵» */
function formatJalaliShort(dateInput) {
  const j = toJalali(dateInput);
  return `${toPersianDigits(j.day)} ${j.monthName} ${toPersianDigits(j.year)}`;
}

/** تاریخ و ساعت مثل «۱۹ تیر، ۱۴:۳۰» */
function formatJalaliDateTime(dateInput) {
  const d = new Date(dateInput);
  const j = toJalali(d);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${toPersianDigits(j.day)} ${j.monthName}، ${toPersianDigits(hh)}:${toPersianDigits(mm)}`;
}

module.exports = { toJalali, formatJalaliFull, formatJalaliShort, formatJalaliDateTime, toPersianDigits };
