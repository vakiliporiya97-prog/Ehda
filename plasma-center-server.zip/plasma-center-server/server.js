require("dotenv").config();
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");

const { mutate } = require("./src/db");
const authRoutes = require("./src/routes/auth");
const donorRoutes = require("./src/routes/donors");
const adminRoutes = require("./src/routes/admin");

const app = express();
const PORT = process.env.PORT || 3000;

/* ---------- امنیت پایه ---------- */
app.set("trust proxy", 1); // برای اجرای درست پشت پراکسی سرویس‌های هاست (Render/Railway و ...)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdnjs.cloudflare.com"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
      },
    },
  })
);
app.use(express.json({ limit: "200kb" }));
app.use(cookieParser());

// محدودیت تعداد تلاش برای ورود کارکنان — جلوگیری از حدس زدن رمز عبور
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false });
app.use("/api/auth/login", loginLimiter);

// محدودیت کلی روی API عمومی برای جلوگیری از سوءاستفاده
const publicLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use("/api/donors", publicLimiter);

/* ---------- مسیرها ---------- */
app.use("/api/auth", authRoutes);
app.use("/api/donors", donorRoutes);
app.use("/api/admin", adminRoutes);

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

/* ---------- ساخت خودکار حساب مدیر در اولین اجرا ---------- */
function bootstrapAdmin() {
  const username = process.env.ADMIN_USERNAME;
  const password = process.env.ADMIN_PASSWORD;
  mutate((db) => {
    if (db.staff.length > 0) return; // اگه قبلاً کاربری ساخته شده، کاری نکن
    if (!username || !password) {
      console.warn("⚠️  ADMIN_USERNAME / ADMIN_PASSWORD در .env تنظیم نشده — هیچ حساب مدیری ساخته نشد.");
      return;
    }
    db.staff.push({
      id: db.nextIds.staff++,
      username,
      passwordHash: bcrypt.hashSync(password, 12),
      role: "admin",
      mustChangePassword: true,
      createdAt: new Date().toISOString(),
    });
    console.log(`✅ حساب مدیر اولیه ساخته شد (نام کاربری: ${username}). لطفاً بعد از ورود، رمز رو عوض کنید.`);
  });
}

bootstrapAdmin();

app.listen(PORT, () => {
  console.log(`🩸 سرور مرکز اهدا پلاسما روی پورت ${PORT} در حال اجراست`);
});
