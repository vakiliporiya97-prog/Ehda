/* ============================================================
   مرکز اهدا پلاسما نوین پلاسما پورا دارو — فرانت‌اند بدون فریم‌ورک
   ============================================================ */

/* ---------- ابزار API ---------- */
async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* بدنه‌ی خالی */ }
  if (!res.ok) throw new Error((data && data.error) || "خطای ناشناخته سرور");
  return data;
}

/* ---------- امنیت نمایش: جلوگیری از تزریق HTML توسط متن‌های کاربر ---------- */
function esc(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

/* ---------- تبدیل تاریخ میلادی به شمسی (سمت کلاینت) ---------- */
const FA_MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
const FA_WEEKDAYS = ["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"];
function faDigits(n) {
  const map = {0:"۰",1:"۱",2:"۲",3:"۳",4:"۴",5:"۵",6:"۶",7:"۷",8:"۸",9:"۹"};
  return String(n).replace(/[0-9]/g, (c) => map[c]);
}
function gToJalali(gy, gm, gd) {
  const g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
  let gy2 = gm > 2 ? gy + 1 : gy;
  let days = 355666 + 365*gy + Math.floor((gy2+3)/4) - Math.floor((gy2+99)/100) + Math.floor((gy2+399)/400) + gd + g_d_m[gm-1];
  let jy = -1595 + 33 * Math.floor(days/12053);
  days %= 12053;
  jy += 4 * Math.floor(days/1461);
  days %= 1461;
  if (days > 365) { jy += Math.floor((days-1)/365); days = (days-1) % 365; }
  let jm, jd;
  if (days < 186) { jm = 1 + Math.floor(days/31); jd = 1 + (days % 31); }
  else { jm = 7 + Math.floor((days-186)/30); jd = 1 + ((days-186) % 30); }
  return [jy, jm, jd];
}
function jalaliParts(dateInput) {
  const d = new Date(dateInput);
  const [jy, jm, jd] = gToJalali(d.getFullYear(), d.getMonth()+1, d.getDate());
  return { year: jy, month: jm, day: jd, monthName: FA_MONTHS[jm-1], weekday: FA_WEEKDAYS[d.getDay()], _d: d };
}
function fmtDate(dateInput) {
  if (!dateInput) return "-";
  const j = jalaliParts(dateInput);
  return `${j.weekday} ${faDigits(j.day)} ${j.monthName} ${faDigits(j.year)}`;
}
function fmtDateShort(dateInput) {
  if (!dateInput) return "-";
  const j = jalaliParts(dateInput);
  return `${faDigits(j.day)} ${j.monthName} ${faDigits(j.year)}`;
}
function fmtDateTime(dateInput) {
  if (!dateInput) return "-";
  const j = jalaliParts(dateInput);
  const hh = String(j._d.getHours()).padStart(2, "0");
  const mm = String(j._d.getMinutes()).padStart(2, "0");
  return `${faDigits(j.day)} ${j.monthName}، ${faDigits(hh)}:${faDigits(mm)}`;
}

/* ---------- ثابت‌ها ---------- */
const DONATION_SYMPTOMS = [
  "تهوع","سرگیجه","بی‌حالی یا خستگی غیرعادی","گزگز یا بی‌حسی لب و انگشتان",
  "کبودی یا درد محل تزریق","لرز یا تب","ضعف شدید یا نزدیک به غش",
];
const WEEKDAY_LABELS = ["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"];

/* ---------- وضعیت کلی برنامه ---------- */
const state = {
  screen: "landing",
  donor: null,
  donorMessages: [],
  activeVisitId: null,
  toast: null,
  staff: null,
  publicSettings: null,
  form: {}, // وضعیت موقت فرم‌های چندمرحله‌ای (امتیازها، علائم و ...)
  admin: { donors: null, settings: null, users: null, selectedPhone: null, selectedDonor: null, selectedMessages: null },
  busy: false,
  errorMsg: null,
};

function setScreen(screen, resetForm = true) {
  state.screen = screen;
  if (resetForm) state.form = {};
  state.errorMsg = null;
  render();
  window.scrollTo(0, 0);
}
function showToast(msg, tone = "emerald") {
  state.toast = { msg, tone };
  render();
  setTimeout(() => { state.toast = null; render(); }, 3200);
}

/* ============================================================
   قطعه‌های قابل‌استفاده‌ی مجدد رابط کاربری (به‌صورت رشته‌ی HTML)
   ============================================================ */

function TopBar(title, backAction) {
  return `
    <div class="flex items-center justify-between mb-5">
      ${backAction ? `<button data-action="${backAction}" class="p-2 -mr-2 text-teal-800">&#8592;</button>` : `<div class="w-9"></div>`}
      <h1 class="font-bold text-lg text-teal-950">${esc(title)}</h1>
      <div class="w-9"></div>
    </div>`;
}

function Badge(text, tone = "slate") {
  const tones = {
    slate: "bg-stone-100 text-stone-600", amber: "bg-amber-100 text-amber-800",
    emerald: "bg-emerald-100 text-emerald-700", rose: "bg-rose-100 text-rose-700",
    teal: "bg-teal-100 text-teal-800",
  };
  return `<span class="px-2.5 py-1 rounded-full text-xs font-medium ${tones[tone]}">${esc(text)}</span>`;
}

function PrimaryButton(label, action, opts = {}) {
  const disabled = opts.disabled ? "disabled" : "";
  const extraClass = opts.className || "";
  const dataAttrs = opts.data ? Object.entries(opts.data).map(([k, v]) => `data-${k}="${esc(v)}"`).join(" ") : "";
  return `<button data-action="${action}" ${dataAttrs} ${disabled}
      class="w-full py-3.5 rounded-xl font-bold text-white bg-amber-500 hover:bg-amber-600 active:scale-[0.99]
      disabled:bg-stone-300 disabled:cursor-not-allowed transition-all shadow-sm ${extraClass}">${esc(label)}</button>`;
}

function GhostButton(label, action) {
  return `<button data-action="${action}" class="w-full py-3 rounded-xl font-semibold text-teal-800 bg-teal-50 hover:bg-teal-100 transition-colors">${esc(label)}</button>`;
}

function DropProgress(count, cap) {
  const size = 88, stroke = 8, r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const pct = Math.min(count / cap, 1);
  return `
    <div class="relative" style="width:${size}px;height:${size}px">
      <svg width="${size}" height="${size}" style="transform:rotate(-90deg)">
        <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#e7e5e4" stroke-width="${stroke}"></circle>
        <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#d97706" stroke-width="${stroke}"
          stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c*(1-pct)}"
          style="transition:stroke-dashoffset .5s ease"></circle>
      </svg>
      <div class="absolute inset-0 flex flex-col items-center justify-center">
        <span class="text-amber-600 text-lg leading-none">&#128167;</span>
        <span class="text-xs font-bold text-teal-900 mt-0.5">${faDigits(count)}/${faDigits(cap)}</span>
      </div>
    </div>`;
}

function ScaleInput(name, value) {
  const v = state.form[name] || 0;
  return `<div class="flex justify-between gap-1.5">
    ${[1,2,3,4,5].map((n) => `
      <button data-action="setForm" data-key="${name}" data-value="${n}"
        class="flex-1 py-2.5 rounded-lg text-sm font-bold border transition-colors ${v===n ? "bg-teal-800 text-white border-teal-800" : "bg-white text-stone-500 border-stone-200"}">${faDigits(n)}</button>
    `).join("")}
  </div>`;
}

function RatingRow(label, name) {
  return `<div><p class="text-sm text-stone-700 mb-2">${esc(label)}</p>${ScaleInput(name)}</div>`;
}

function SurveySection(title, innerHtml) {
  return `<div class="space-y-4">
    <p class="text-xs font-extrabold text-teal-800 tracking-wide border-b border-stone-100 pb-2">${esc(title)}</p>
    ${innerHtml}
  </div>`;
}

function FeelingPicker(name) {
  const v = state.form[name];
  const opts = [["خوب","emerald","&#128578;"],["متوسط","amber","&#128528;"],["ضعیف","rose","&#128577;"]];
  const toneBg = { emerald: "border-teal-800 bg-teal-50", amber: "border-teal-800 bg-teal-50", rose: "border-teal-800 bg-teal-50" };
  return `<div class="grid grid-cols-3 gap-3">
    ${opts.map(([label, tone, icon]) => `
      <button data-action="setForm" data-key="${name}" data-value="${label}"
        class="py-4 rounded-xl border flex flex-col items-center gap-1.5 transition-colors ${v===label ? "border-teal-800 bg-teal-50" : "border-stone-200 bg-white"}">
        <span class="text-2xl leading-none">${icon}</span>
        <span class="text-sm font-semibold text-stone-700">${label}</span>
      </button>
    `).join("")}
  </div>`;
}

function SymptomChecklist(name) {
  const arr = state.form[name] || [];
  const all = [...DONATION_SYMPTOMS, "هیچ‌کدام"];
  return `<div class="flex flex-wrap gap-2">
    ${all.map((s) => {
      const active = arr.includes(s);
      const activeClass = active ? (s === "هیچ‌کدام" ? "bg-emerald-600 text-white border-emerald-600" : "bg-rose-600 text-white border-rose-600") : "bg-white text-stone-600 border-stone-200";
      return `<button data-action="toggleSymptom" data-key="${name}" data-value="${esc(s)}"
        class="px-3 py-2 rounded-full text-xs font-semibold border transition-colors ${activeClass}">${esc(s)}</button>`;
    }).join("")}
  </div>`;
}

function Card(innerHtml, extraClass = "") {
  return `<div class="bg-white rounded-2xl shadow-sm border border-stone-200 ${extraClass}">${innerHtml}</div>`;
}

function Toast() {
  if (!state.toast) return "";
  const cls = state.toast.tone === "rose" ? "bg-rose-100 text-rose-700" : "bg-emerald-100 text-emerald-700";
  return `<div class="mb-4 p-3 rounded-xl text-sm font-semibold text-center ${cls}">${esc(state.toast.msg)}</div>`;
}

function ErrorBox() {
  if (!state.errorMsg) return "";
  return `<div class="mb-4 p-3 rounded-xl text-sm font-semibold text-center bg-rose-100 text-rose-700">${esc(state.errorMsg)}</div>`;
}

/* ============================================================
   صفحه‌ی ورود اصلی
   ============================================================ */
function screenLanding() {
  const name = (state.publicSettings && state.publicSettings.centerName) || "مرکز اهدا پلاسما نوین پلاسما پورا دارو";
  return `
    <div class="min-h-screen flex flex-col items-center justify-center p-6">
      <div class="w-full max-w-sm fade-in">
        <div class="flex flex-col items-center mb-10">
          <div class="w-16 h-16 rounded-2xl bg-teal-900 flex items-center justify-center mb-4 shadow-lg shadow-teal-900/20">
            <span class="text-3xl">&#128167;</span>
          </div>
          <h1 class="text-2xl font-extrabold text-teal-950 text-center">${esc(name)}</h1>
          <p class="text-stone-500 text-sm mt-1">پایش نوبت، سلامت و تجربه‌ی اهداکنندگان</p>
        </div>
        <div class="space-y-3">
          ${PrimaryButton("من اهداکننده‌ام", "goDonorAuth")}
          ${GhostButton("ورود کارکنان مرکز", "goStaffLogin")}
        </div>
      </div>
    </div>`;
}

/* ============================================================
   مسیر اهداکننده
   ============================================================ */
function screenDonorAuth() {
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("ورود اهداکننده", "goLanding")}
    ${ErrorBox()}
    ${Card(`<div class="p-5">
      <div class="flex items-center gap-2 text-teal-800 mb-4 text-sm font-semibold">شماره موبایل خود را وارد کنید</div>
      <input id="phoneInput" inputmode="numeric" placeholder="09xxxxxxxxx"
        class="w-full border border-stone-200 rounded-xl px-4 py-3 text-lg tracking-wider text-center mb-4 focus:outline-none focus:ring-2 focus:ring-amber-400" />
      ${PrimaryButton("ادامه", "donorAuthSubmit")}
    </div>`)}
  </div>`;
}

function screenDonorRegister() {
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("ثبت‌نام", "goDonorAuth")}
    ${ErrorBox()}
    ${Card(`<div class="p-5">
      <p class="text-sm text-stone-500 mb-4">اولین حضورتونه! لطفاً نامتون رو وارد کنید تا پرونده‌تون ساخته بشه.</p>
      <label class="text-xs font-semibold text-stone-500">شماره موبایل</label>
      <div class="border border-stone-200 rounded-xl px-4 py-3 mb-4 mt-1 text-stone-500 bg-stone-50">${esc(state.form.phone || "")}</div>
      <label class="text-xs font-semibold text-stone-500">نام و نام‌خانوادگی</label>
      <input id="nameInput" placeholder="مثلاً سارا احمدی"
        class="w-full border border-stone-200 rounded-xl px-4 py-3 mb-4 mt-1 focus:outline-none focus:ring-2 focus:ring-amber-400" />
      ${PrimaryButton("ساخت پرونده", "donorRegisterSubmit")}
    </div>`)}
  </div>`;
}

function screenDonorHome() {
  const d = state.donor;
  if (!d) return `<div class="p-10 text-center text-stone-400">در حال بارگذاری...</div>`;

  if (d.status === "awaiting_approval") {
    const s = state.publicSettings || {};
    return `<div class="max-w-sm mx-auto p-5">
      ${TopBar("در انتظار تایید", "donorLogout")}
      ${Toast()}
      ${Card(`<div class="p-6 text-center">
        <div class="w-14 h-14 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-4"><span class="text-2xl">&#9203;</span></div>
        <p class="font-bold text-teal-950 mb-1">سلام ${esc(d.name)} عزیز</p>
        <p class="text-sm text-stone-500 mb-2">نمونه‌ی اولیه‌ی شما در ${fmtDateShort(d.screeningDate)} ثبت شد.</p>
        <p class="text-sm text-stone-500 mb-6">نتیجه و تاییدیه‌ی اهدا معمولاً بین ${faDigits(s.labWaitMinDays||7)} تا ${faDigits(s.labWaitMaxDays||10)} روز بعد آماده می‌شه. بعد از تایید مدیر، خودتون می‌تونید نوبت اهدا رو ثبت کنید.</p>
        ${PrimaryButton("بررسی وضعیت تایید", "refreshDonor")}
      </div>`)}
      ${donorMessagesSection()}
    </div>`;
  }

  const monthLabel = `این ماه: ${faDigits(d.visits.filter(v=>v.type==="donation").length)} اهدا`;
  const recent = [...d.visits].sort((a,b)=> new Date(b.date)-new Date(a.date)).slice(0,4);

  return `<div class="max-w-sm mx-auto p-5 pb-10">
    <div class="flex items-center justify-between mb-5">
      <button data-action="donorLogout" class="p-2 -ml-2 text-stone-400">&#8674;</button>
      <div class="text-center"><p class="text-xs text-stone-400">خوش اومدی</p><p class="font-bold text-teal-950">${esc(d.name)}</p></div>
      ${DropProgress(d.visits.filter(v=>v.type==="donation" && sameJalaliMonth(v.date)).length, 3)}
    </div>
    ${Toast()}${ErrorBox()}

    ${d.needsRescreen ? Card(`<div class="p-4 flex items-center gap-3">
        <span class="text-2xl">&#129530;</span>
        <div><p class="font-bold text-teal-950">نیاز به نمونه‌گیری مجدد</p>
        <p class="text-xs text-stone-500">اعتبار آخرین نمونه‌ی شما تموم شده؛ لطفاً یک ویزیت غربالگری جدید ثبت کنید.</p></div>
      </div>`, "mb-4 bg-amber-50 border-amber-200") : `
      <div class="mb-4">${Card(`<div class="p-4 flex items-center gap-3">
        <span class="text-2xl">${d.eligibleNow ? "&#9989;" : "&#128197;"}</span>
        <div>
          <p class="font-bold text-teal-950">${d.eligibleNow ? "امروز می‌تونید اهدا کنید" : `نوبت بعدی: ${fmtDate(d.nextEligibleDate)}`}</p>
          <p class="text-xs text-stone-500">فاصله‌ی مجاز بین اهداها طبق تنظیمات مرکز رعایت می‌شه</p>
        </div>
      </div>`, d.eligibleNow ? "bg-emerald-50 border-emerald-200" : "bg-stone-50")}</div>`
    }

    ${d.pendingFollowUp ? Card(`<div class="p-4">
        <div class="flex items-center gap-3 mb-3"><span class="text-2xl">&#128202;</span>
          <div><p class="font-bold text-teal-950">پایش سلامت بعد از اهدا</p>
          <p class="text-xs text-stone-500">لطفاً وضعیت‌تون بعد از اهدای ${fmtDateShort(d.pendingFollowUp.date)} رو گزارش بدید</p></div>
        </div>
        ${PrimaryButton("تکمیل پایش سلامت", "openFollowUp", { data: { visit: d.pendingFollowUp.id } })}
      </div>`, "mb-4 bg-amber-50 border-amber-200") : ""
    }

    ${donorMessagesSection()}

    ${PrimaryButton("+ ثبت ویزیت امروز", "donorStartVisit", { className: "mb-6" })}

    <p class="text-xs font-bold text-stone-400 mb-2">ویزیت‌های اخیر</p>
    <div class="space-y-2">
      ${recent.length === 0 ? `<p class="text-sm text-stone-400 text-center py-6">هنوز ویزیتی ثبت نشده</p>` : recent.map((v) => `
        ${Card(`<div class="p-3.5 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <span class="text-xl">${v.type === "donation" ? "&#128167;" : "&#129502;"}</span>
            <div><p class="text-sm font-semibold text-teal-950">${v.type === "donation" ? "اهدای پلاسما" : "آزمایش و غربالگری"}</p>
            <p class="text-xs text-stone-400">${fmtDateTime(v.date)}</p></div>
          </div>
          ${(v.immediateCheck && v.immediateCheck.concerning) || (v.followUp && v.followUp.concerning) ? Badge("نیاز به پیگیری","rose") : ""}
        </div>`)}
      `).join("")}
    </div>
  </div>`;
}

function sameJalaliMonth(dateStr) {
  const now = new Date(), d = new Date(dateStr);
  return now.getFullYear() === d.getFullYear() && now.getMonth() === d.getMonth();
}

function donorMessagesSection() {
  const msgs = state.donorMessages || [];
  if (msgs.length === 0) return "";
  const latest = msgs[0];
  return `<div class="mb-4">${Card(`<div class="p-4">
    <div class="flex items-center gap-2 mb-2 text-teal-800 font-bold text-sm">&#128172; پیام از مرکز</div>
    <p class="text-sm text-stone-700 mb-2">${esc(latest.body)}</p>
    ${latest.appointmentDate ? `<div class="mt-2 p-2.5 rounded-lg bg-amber-50 text-amber-800 text-sm font-semibold">نوبت تعیین‌شده: ${fmtDateTime(latest.appointmentDate)}</div>` : ""}
    <p class="text-xs text-stone-400 mt-2">${fmtDateShort(latest.createdAt)}</p>
  </div>`, "bg-teal-50 border-teal-200")}</div>`;
}

function screenDonorVisitPick() {
  const d = state.donor;
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("نوع ویزیت امروز", "backToDonorHome")}
    ${ErrorBox()}
    <div class="space-y-3">
      <button data-action="donorCreateVisit" data-type="screening" class="w-full text-right p-4 bg-white border border-stone-200 rounded-2xl flex items-center gap-3 hover:border-teal-300">
        <span class="text-2xl">&#129502;</span>
        <div><div class="font-bold text-teal-950">آزمایش و غربالگری</div><div class="text-xs text-stone-500">برای بررسی سلامت قبل از اهدا</div></div>
      </button>
      <button data-action="donorCreateVisit" data-type="donation" ${d.eligibleNow ? "" : "disabled"}
        class="w-full text-right p-4 bg-white border border-stone-200 rounded-2xl flex items-center gap-3 hover:border-teal-300 disabled:opacity-40">
        <span class="text-2xl">&#128167;</span>
        <div><div class="font-bold text-teal-950">اهدای پلاسما</div>
        <div class="text-xs text-stone-500">${d.eligibleNow ? "امروز نوبت اهداست" : (d.needsRescreen ? "ابتدا نیاز به نمونه‌گیری مجدد" : `قابل ثبت از ${fmtDate(d.nextEligibleDate)}`)}</div></div>
      </button>
    </div>
  </div>`;
}

function screenDonorSurvey() {
  const visit = state.donor.visits.find((v) => v.id === state.activeVisitId);
  const isDonation = visit.type === "donation";
  const f = state.form;
  const commonFilled = f.receptionBehavior && f.receptionSpeed && f.doctorBehavior && f.doctorExplanation &&
    f.securityConduct && f.respectSafety && f.cleanlinessWaiting && f.cleanlinessDonationRoom && f.wayfinding && f.accessibility;
  const complete = isDonation ? commonFilled && f.satisfaction && f.comfort : commonFilled && f.howHeard;

  return `<div class="max-w-sm mx-auto p-5 pb-10">
    ${TopBar(isDonation ? "نظرسنجی اهدا" : "نظرسنجی غربالگری")}
    ${Card(`<div class="p-5 space-y-6">
      ${!isDonation ? SurveySection("آشنایی با مرکز", `
        <div><p class="text-sm text-stone-700 mb-2">چطور با مرکز آشنا شدید؟</p>
          <div class="grid grid-cols-2 gap-2">
            ${["معرفی دوستان","شبکه‌های اجتماعی","تابلو/بروشور","سایر"].map((o) => `
              <button data-action="setForm" data-key="howHeard" data-value="${esc(o)}"
                class="py-2.5 rounded-lg text-sm border ${f.howHeard===o ? "bg-teal-800 text-white border-teal-800" : "bg-white border-stone-200 text-stone-600"}">${esc(o)}</button>
            `).join("")}
          </div>
        </div>`) : ""}

      ${SurveySection("پذیرش", RatingRow("برخورد و راهنمایی کارکنان پذیرش","receptionBehavior") + RatingRow("سرعت انجام پذیرش","receptionSpeed"))}
      ${SurveySection("پزشک و کادر درمان", RatingRow("برخورد پزشک/کادر درمان","doctorBehavior") + RatingRow("وضوح توضیحات پزشک درباره‌ی فرآیند","doctorExplanation"))}
      ${SurveySection("حراست و اخلاق برخورد", RatingRow("برخورد حراست/نگهبانی","securityConduct") + RatingRow("احساس احترام و امنیت در طول حضور","respectSafety"))}
      ${SurveySection("نظافت مرکز", RatingRow("نظافت سالن انتظار","cleanlinessWaiting") + RatingRow("نظافت اتاق/تخت اهدا","cleanlinessDonationRoom"))}
      ${SurveySection("مسیر و دسترسی", RatingRow("سهولت پیدا کردن مسیر و تابلوها","wayfinding") + RatingRow("دسترسی مناسب (پله/آسانسور/پارکینگ)","accessibility"))}
      ${isDonation ? SurveySection("فرآیند اهدا", RatingRow("رضایت کلی از فرآیند اهدای امروز","satisfaction") + RatingRow("راحتی طی فرآیند اهدا","comfort")) : ""}

      <div><p class="text-sm font-semibold text-teal-950 mb-2">نظر یا پیشنهادی دارید؟ (اختیاری)</p>
        <textarea id="notesInput" rows="3" class="w-full border border-stone-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-amber-400"></textarea>
      </div>

      ${PrimaryButton("ثبت پاسخ‌ها", "donorSubmitSurvey", { disabled: !complete })}
    </div>`)}
  </div>`;
}

function screenDonorImmediateCheck() {
  const f = state.form;
  const complete = (f.symptoms && f.symptoms.length > 0) && f.feeling;
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("وضعیت سلامت همین الان")}
    ${Card(`<div class="p-5 space-y-5">
      <div><p class="text-sm font-semibold text-teal-950 mb-2">همین الان کدام مورد رو احساس می‌کنید؟</p>
        <p class="text-xs text-stone-400 mb-3">می‌تونید چند مورد رو انتخاب کنید</p>
        ${SymptomChecklist("symptoms")}
      </div>
      <div><p class="text-sm font-semibold text-teal-950 mb-2">در کل احساستون چطوره؟</p>${FeelingPicker("feeling")}</div>
      ${PrimaryButton("ثبت وضعیت", "donorSubmitImmediate", { disabled: !complete })}
      <p class="text-xs text-stone-400 text-center">این ابزار جایگزین نظر پزشک نیست. در صورت احساس ناخوشی جدی، فوراً به کارکنان مرکز اطلاع بدید.</p>
    </div>`)}
  </div>`;
}

function screenDonorFollowUp() {
  const visit = state.donor.visits.find((v) => v.id === state.activeVisitId);
  const f = state.form;
  const complete = (f.symptoms && f.symptoms.length > 0) && f.feeling;
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("پایش سلامت بعد از اهدا")}
    ${Card(`<div class="p-5 space-y-5">
      <p class="text-xs text-stone-400">از زمان اهدای شما در ${fmtDate(visit.date)} می‌پرسیم:</p>
      <div><p class="text-sm font-semibold text-teal-950 mb-2">کدام مورد رو تجربه کردید؟</p>
        <p class="text-xs text-stone-400 mb-3">می‌تونید چند مورد رو انتخاب کنید</p>
        ${SymptomChecklist("symptoms")}
      </div>
      <div><p class="text-sm font-semibold text-teal-950 mb-2">در کل حالتون چطوره؟</p>${FeelingPicker("feeling")}</div>
      ${PrimaryButton("ثبت پایش", "donorSubmitFollowUp", { disabled: !complete })}
    </div>`)}
  </div>`;
}

/* ============================================================
   مسیر کارکنان
   ============================================================ */
function screenStaffLogin() {
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("ورود کارکنان", "goLanding")}
    ${ErrorBox()}
    ${Card(`<div class="p-5">
      <label class="text-xs font-semibold text-stone-500">نام کاربری</label>
      <input id="staffUsername" class="w-full border border-stone-200 rounded-xl px-4 py-3 mb-3 mt-1 focus:outline-none focus:ring-2 focus:ring-amber-400" />
      <label class="text-xs font-semibold text-stone-500">رمز عبور</label>
      <input id="staffPassword" type="password" class="w-full border border-stone-200 rounded-xl px-4 py-3 mb-4 mt-1 focus:outline-none focus:ring-2 focus:ring-amber-400" />
      ${PrimaryButton("ورود", "staffLoginSubmit")}
    </div>`)}
  </div>`;
}

function screenChangePassword(forced) {
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("تغییر رمز عبور", forced ? null : "goStaffDashboard")}
    ${ErrorBox()}
    ${forced ? `<div class="mb-4 p-3 rounded-xl text-sm bg-amber-100 text-amber-800 text-center">برای امنیت حساب‌تون، لطفاً همین الان رمز رو عوض کنید.</div>` : ""}
    ${Card(`<div class="p-5 space-y-3">
      <div><label class="text-xs font-semibold text-stone-500">رمز فعلی</label>
        <input id="curPass" type="password" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1 focus:outline-none focus:ring-2 focus:ring-amber-400" /></div>
      <div><label class="text-xs font-semibold text-stone-500">رمز جدید (حداقل ۸ کاراکتر)</label>
        <input id="newPass" type="password" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1 focus:outline-none focus:ring-2 focus:ring-amber-400" /></div>
      ${PrimaryButton("ثبت رمز جدید", "submitChangePassword")}
    </div>`)}
  </div>`;
}

function statCard(icon, label, value) {
  return Card(`<div class="p-4">
    <div class="w-9 h-9 rounded-lg flex items-center justify-center mb-2 bg-teal-50 text-lg">${icon}</div>
    <p class="text-2xl font-extrabold text-teal-950">${faDigits(value)}</p>
    <p class="text-xs text-stone-400">${esc(label)}</p>
  </div>`);
}

function screenStaffDashboard() {
  const donors = state.admin.donors || [];
  const awaiting = donors.filter((d) => d.status === "awaiting_approval");
  const approved = donors.filter((d) => d.status === "approved");
  const flagged = approved.filter((d) => d.flagged).length;
  const pendingFollow = approved.filter((d) => d.pendingFollowUp).length;
  const totalDonationsThisMonth = approved.reduce((sum, d) => sum + d.visits.filter(v => v.type === "donation" && sameJalaliMonth(v.date)).length, 0);
  const dueToday = approved.filter((d) => d.eligibleNow && d.visits.some(v => v.type === "donation"));

  return `<div class="max-w-3xl mx-auto p-5 pb-10">
    <div class="flex items-center justify-between mb-6">
      <button data-action="staffLogout" class="text-stone-500 text-sm font-semibold">&#8674; خروج</button>
      <h1 class="font-bold text-lg text-teal-950">&#128737; پنل مدیریت مرکز</h1>
      <button data-action="goChangePassword" class="text-teal-800 text-sm font-semibold">تغییر رمز</button>
    </div>
    ${ErrorBox()}${Toast()}

    ${state.staff.role === "admin" ? `<div class="grid grid-cols-2 gap-3 mb-4">
      ${GhostButton("&#9881; تنظیمات مرکز", "goStaffSettings")}
      ${GhostButton("&#128101; مدیریت کارکنان", "goStaffUsers")}
    </div>` : ""}

    ${awaiting.length > 0 ? Card(`<div class="p-4">
      <div class="flex items-center gap-2 mb-3 text-amber-800 font-bold text-sm">&#9203; در انتظار تایید (${faDigits(awaiting.length)} نفر)</div>
      <div class="space-y-2">
        ${awaiting.map((d) => `<div class="bg-white rounded-xl p-3 flex items-center justify-between border border-amber-100">
          <div><p class="font-semibold text-sm text-teal-950">${esc(d.name)}</p>
          <p class="text-xs text-stone-400">${esc(d.phone)} · نمونه در ${fmtDateShort(d.screeningDate)}</p></div>
          <div class="flex gap-2">
            <button data-action="openDonorDetail" data-phone="${esc(d.phone)}" class="px-3 py-2 bg-stone-100 text-stone-600 text-xs font-bold rounded-lg">جزئیات</button>
            <button data-action="approveDonor" data-phone="${esc(d.phone)}" class="px-3 py-2 bg-emerald-600 text-white text-xs font-bold rounded-lg">تایید</button>
          </div>
        </div>`).join("")}
      </div>
    </div>`, "mb-6 bg-amber-50 border-amber-200") : ""}

    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
      ${statCard("&#128101;","اهداکنندگان",donors.length)}
      ${statCard("&#128167;","اهدای این ماه",totalDonationsThisMonth)}
      ${statCard("&#9888;","نیازمند پیگیری",flagged)}
      ${statCard("&#9203;","پایش معوق",pendingFollow)}
    </div>

    ${dueToday.length > 0 ? Card(`<div class="p-4">
      <div class="flex items-center gap-2 mb-3 text-teal-900 font-bold text-sm">&#128222; برای یادآوری تماس بگیرید (${faDigits(dueToday.length)} نفر)</div>
      <div class="flex flex-wrap gap-2">
        ${dueToday.map((d) => `<button data-action="openDonorDetail" data-phone="${esc(d.phone)}" class="px-3 py-1.5 bg-white rounded-full text-sm border border-teal-200 text-teal-900 font-medium">${esc(d.name)} · ${esc(d.phone)}</button>`).join("")}
      </div>
    </div>`, "mb-6 bg-teal-50 border-teal-200") : ""}

    <p class="text-xs font-bold text-stone-400 mb-2">همه‌ی اهداکنندگان</p>
    <div class="space-y-2">
      ${donors.length === 0 ? `<p class="text-sm text-stone-400 text-center py-10">هنوز اهداکننده‌ای ثبت نشده</p>` : donors.map((d) => `
        <button data-action="openDonorDetail" data-phone="${esc(d.phone)}" class="w-full text-right">
          ${Card(`<div class="p-4 flex items-center justify-between hover:border-teal-300">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-full bg-teal-900 text-white flex items-center justify-center font-bold">${esc(d.name.charAt(0))}</div>
              <div><p class="font-bold text-teal-950">${esc(d.name)}</p>
              <p class="text-xs text-stone-400">${esc(d.phone)} · ${faDigits(d.visits.filter(v=>v.type==="donation").length)} اهدا</p></div>
            </div>
            <div class="flex items-center gap-2">
              ${d.flagged ? Badge("پیگیری","rose") : ""}
              ${d.pendingFollowUp ? Badge("پایش معوق","amber") : ""}
              ${d.status === "awaiting_approval" ? Badge("در انتظار تایید","amber") :
                d.status === "new" ? Badge("جدید","slate") :
                Badge(d.eligibleNow ? "آماده اهدا" : fmtDateShort(d.nextEligibleDate), d.eligibleNow ? "emerald" : "slate")}
            </div>
          </div>`)}
        </button>
      `).join("")}
    </div>
  </div>`;
}

function screenStaffDonorDetail() {
  const d = state.admin.selectedDonor;
  if (!d) return `<div class="p-10 text-center text-stone-400">در حال بارگذاری...</div>`;
  const visits = [...d.visits].sort((a,b)=> new Date(b.date)-new Date(a.date));
  const messages = state.admin.selectedMessages || [];

  return `<div class="max-w-2xl mx-auto p-5 pb-10">
    ${TopBar(d.name, "goStaffDashboard")}
    ${ErrorBox()}${Toast()}

    ${Card(`<div class="p-4 flex items-center justify-between mb-5">
      <div>
        <p class="text-sm text-stone-500">${esc(d.phone)}</p>
        <p class="text-xs text-stone-400">عضویت از ${fmtDate(d.createdAt)}</p>
        <div class="mt-2 flex gap-2">
          ${d.status === "awaiting_approval" ? Badge("در انتظار تایید","amber") : d.status === "new" ? Badge("جدید","slate") : Badge("تاییدشده","emerald")}
          ${d.flagged ? Badge("نیازمند پیگیری","rose") : ""}
        </div>
      </div>
      ${DropProgress(d.visits.filter(v=>v.type==="donation" && sameJalaliMonth(v.date)).length, 3)}
    </div>`, "mb-5")}

    ${d.status === "awaiting_approval" ? Card(`<div class="p-4">
      <p class="text-sm text-stone-600 mb-3">نمونه در ${fmtDate(d.screeningDate)} گرفته شده. بعد از تایید، این فرد خودش می‌تونه نوبت اهدا رو ثبت کنه.</p>
      ${PrimaryButton("تایید برای اهدا", "approveDonor", { data: { phone: d.phone } })}
    </div>`, "mb-5 bg-amber-50 border-amber-200") : ""}

    ${Card(`<div class="p-4">
      <p class="text-xs font-bold text-teal-800 mb-3">تنظیمات اختصاصی این فرد (اختیاری)</p>
      <div class="grid grid-cols-2 gap-3 mb-3">
        <div><label class="text-xs text-stone-500">فاصله‌ی اهدا (روز)</label>
          <input id="ovGapDays" type="number" min="1" placeholder="پیش‌فرض مرکز"
            value="${d.overrides && d.overrides.minGapHours ? Math.round(d.overrides.minGapHours/24) : ""}"
            class="w-full border border-stone-200 rounded-lg px-3 py-2 mt-1 text-sm" /></div>
        <div><label class="text-xs text-stone-500">اعتبار نمونه (ماه)</label>
          <input id="ovRescreen" type="number" min="1" placeholder="پیش‌فرض مرکز"
            value="${(d.overrides && d.overrides.rescreenMonths) || ""}"
            class="w-full border border-stone-200 rounded-lg px-3 py-2 mt-1 text-sm" /></div>
      </div>
      <button data-action="saveOverrides" data-phone="${esc(d.phone)}" class="w-full py-2.5 rounded-lg text-sm font-bold text-teal-800 bg-teal-50 hover:bg-teal-100">ذخیره‌ی تنظیمات این فرد</button>
    </div>`, "mb-5")}

    ${Card(`<div class="p-4">
      <p class="text-xs font-bold text-teal-800 mb-3">ارسال پیام و تعیین نوبت</p>
      <textarea id="msgBody" rows="2" placeholder="متن پیام برای اهداکننده..."
        class="w-full border border-stone-200 rounded-lg px-3 py-2 text-sm mb-3"></textarea>
      <label class="text-xs text-stone-500">تاریخ و ساعت نوبت (اختیاری)</label>
      <input id="msgAppointment" type="datetime-local" class="w-full border border-stone-200 rounded-lg px-3 py-2 mt-1 mb-3 text-sm" />
      <button data-action="sendMessage" data-phone="${esc(d.phone)}" class="w-full py-2.5 rounded-lg text-sm font-bold text-white bg-teal-800 hover:bg-teal-900">ارسال</button>
      ${messages.length > 0 ? `<div class="mt-4 space-y-2 border-t border-stone-100 pt-3">
        ${messages.slice(0,5).map(m => `<div class="text-xs text-stone-500">
          <span class="font-semibold text-stone-700">${fmtDateShort(m.createdAt)}:</span> ${esc(m.body)}
          ${m.appointmentDate ? ` — نوبت: ${fmtDateTime(m.appointmentDate)}` : ""}
        </div>`).join("")}
      </div>` : ""}
    </div>`, "mb-5")}

    <p class="text-xs font-bold text-stone-400 mb-2">تاریخچه‌ی ویزیت‌ها</p>
    <div class="space-y-3">
      ${visits.length === 0 ? `<p class="text-sm text-stone-400 text-center py-10">ویزیتی ثبت نشده</p>` : visits.map((v) => {
        const concerning = (v.immediateCheck && v.immediateCheck.concerning) || (v.followUp && v.followUp.concerning);
        let body = "";
        if (v.survey) {
          body += `<div class="text-xs text-stone-500 border-t border-stone-100 pt-2 mt-2 space-y-1">
            <p>پذیرش: برخورد ${faDigits(v.survey.receptionBehavior)}/۵ · سرعت ${faDigits(v.survey.receptionSpeed)}/۵</p>
            <p>پزشک: برخورد ${faDigits(v.survey.doctorBehavior)}/۵ · وضوح توضیحات ${faDigits(v.survey.doctorExplanation)}/۵</p>
            <p>حراست: برخورد ${faDigits(v.survey.securityConduct)}/۵ · احترام و امنیت ${faDigits(v.survey.respectSafety)}/۵</p>
            <p>نظافت: سالن انتظار ${faDigits(v.survey.cleanlinessWaiting)}/۵ · اتاق اهدا ${faDigits(v.survey.cleanlinessDonationRoom)}/۵</p>
            <p>مسیر و دسترسی: تابلوها ${faDigits(v.survey.wayfinding)}/۵ · دسترسی ${faDigits(v.survey.accessibility)}/۵</p>
            ${v.type === "donation" ? `<p>فرآیند اهدا: رضایت کلی ${faDigits(v.survey.satisfaction)}/۵ · راحتی ${faDigits(v.survey.comfort)}/۵</p>` : `<p>آشنایی با مرکز: ${esc(v.survey.howHeard)}</p>`}
            ${v.survey.notes ? `<p class="italic">«${esc(v.survey.notes)}»</p>` : ""}
          </div>`;
        }
        if (v.immediateCheck) body += `<div class="text-xs border-t border-stone-100 pt-2 mt-2 ${v.immediateCheck.concerning ? "text-rose-600 font-semibold" : "text-stone-500"}">همان لحظه: ${esc(v.immediateCheck.symptoms.join("، "))} · حس کلی: ${esc(v.immediateCheck.feeling)}</div>`;
        if (v.followUp) body += `<div class="text-xs border-t border-stone-100 pt-2 mt-2 ${v.followUp.concerning ? "text-rose-600 font-semibold" : "text-stone-500"}">پایش روز بعد: ${esc(v.followUp.symptoms.join("، "))} · حس کلی: ${esc(v.followUp.feeling)}</div>`;
        return Card(`<div class="p-4 ${concerning ? "border border-rose-200 rounded-2xl" : ""}">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <span>${v.type === "donation" ? "&#128167;" : "&#129502;"}</span>
              <span class="font-bold text-sm text-teal-950">${v.type === "donation" ? "اهدای پلاسما" : "آزمایش و غربالگری"}</span>
            </div>
            <span class="text-xs text-stone-400">${fmtDateTime(v.date)}</span>
          </div>
          ${body}
        </div>`);
      }).join("")}
    </div>
  </div>`;
}

function screenStaffSettings() {
  const s = state.admin.settings || {};
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("تنظیمات مرکز", "goStaffDashboard")}
    ${ErrorBox()}${Toast()}
    ${Card(`<div class="p-5 space-y-4">
      <div><label class="text-xs font-semibold text-stone-500">نام مرکز</label>
        <input id="setCenterName" value="${esc(s.centerName || "")}" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1" /></div>
      <div><label class="text-xs font-semibold text-stone-500">فاصله‌ی مجاز بین دو اهدا (روز)</label>
        <input id="setGapDays" type="number" min="1" value="${Math.round((s.minGapHours||240)/24)}" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1" /></div>
      <div><label class="text-xs font-semibold text-stone-500">اعتبار نمونه‌ی غربالگری (ماه)</label>
        <input id="setRescreenMonths" type="number" min="1" value="${s.rescreenMonths||6}" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1" /></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs font-semibold text-stone-500">حداقل انتظار تایید (روز)</label>
          <input id="setLabMin" type="number" min="1" value="${s.labWaitMinDays||7}" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1" /></div>
        <div><label class="text-xs font-semibold text-stone-500">حداکثر انتظار تایید (روز)</label>
          <input id="setLabMax" type="number" min="1" value="${s.labWaitMaxDays||10}" class="w-full border border-stone-200 rounded-xl px-4 py-3 mt-1" /></div>
      </div>
      <div><label class="text-xs font-semibold text-stone-500 mb-2 block">روزهای تعطیلی مرکز</label>
        <div class="grid grid-cols-4 gap-2">
          ${WEEKDAY_LABELS.map((label, idx) => `
            <button data-action="toggleClosedDay" data-day="${idx}"
              class="py-2 rounded-lg text-xs font-semibold border ${(s.closedWeekdays||[]).includes(idx) ? "bg-rose-600 text-white border-rose-600" : "bg-white border-stone-200 text-stone-600"}">${label}</button>
          `).join("")}
        </div>
      </div>
      ${PrimaryButton("ذخیره‌ی تنظیمات", "saveSettings")}
    </div>`)}
  </div>`;
}

function screenStaffUsers() {
  const users = state.admin.users || [];
  return `<div class="max-w-sm mx-auto p-5">
    ${TopBar("مدیریت کارکنان", "goStaffDashboard")}
    ${ErrorBox()}${Toast()}
    ${Card(`<div class="p-5 space-y-3">
      <p class="text-xs font-bold text-teal-800">افزودن کارمند جدید</p>
      <input id="newStaffUsername" placeholder="نام کاربری" class="w-full border border-stone-200 rounded-xl px-4 py-3" />
      <input id="newStaffPassword" type="password" placeholder="رمز عبور موقت (حداقل ۸ کاراکتر)" class="w-full border border-stone-200 rounded-xl px-4 py-3" />
      <select id="newStaffRole" class="w-full border border-stone-200 rounded-xl px-4 py-3">
        <option value="staff">کارمند عادی</option>
        <option value="admin">مدیر</option>
      </select>
      ${PrimaryButton("افزودن کارمند", "addStaffUser")}
    </div>`, "mb-5")}

    <p class="text-xs font-bold text-stone-400 mb-2">کارکنان فعلی</p>
    <div class="space-y-2">
      ${users.map((u) => `${Card(`<div class="p-3.5 flex items-center justify-between">
        <div><p class="font-semibold text-sm text-teal-950">${esc(u.username)}</p>
        <p class="text-xs text-stone-400">${u.role === "admin" ? "مدیر" : "کارمند"}</p></div>
        ${u.id !== state.staff.id ? `<button data-action="deleteStaffUser" data-id="${u.id}" class="text-rose-600 text-xs font-bold">حذف</button>` : `<span class="text-xs text-stone-300">حساب شما</span>`}
      </div>`)}`).join("")}
    </div>
  </div>`;
}

/* ============================================================
   دیسپچر رندر
   ============================================================ */
function render() {
  const app = document.getElementById("app");
  let html;
  switch (state.screen) {
    case "landing": html = screenLanding(); break;
    case "donorAuth": html = screenDonorAuth(); break;
    case "donorRegister": html = screenDonorRegister(); break;
    case "donorHome": html = screenDonorHome(); break;
    case "donorVisitPick": html = screenDonorVisitPick(); break;
    case "donorSurvey": html = screenDonorSurvey(); break;
    case "donorImmediateCheck": html = screenDonorImmediateCheck(); break;
    case "donorFollowUp": html = screenDonorFollowUp(); break;
    case "staffLogin": html = screenStaffLogin(); break;
    case "changePassword": html = screenChangePassword(state.forcedPasswordChange); break;
    case "staffDashboard": html = screenStaffDashboard(); break;
    case "staffDonorDetail": html = screenStaffDonorDetail(); break;
    case "staffSettings": html = screenStaffSettings(); break;
    case "staffUsers": html = screenStaffUsers(); break;
    default: html = screenLanding();
  }
  app.innerHTML = `<div class="fade-in">${html}</div>`;
}

/* ============================================================
   اکشن‌های مسیر اهداکننده
   ============================================================ */
async function goDonorAuth() {
  const cached = localStorage.getItem("donor_phone");
  if (cached) {
    try {
      state.donor = await api("GET", `/api/donors/${cached}`);
      state.donorMessages = await api("GET", `/api/donors/${cached}/messages`);
      setScreen("donorHome");
      return;
    } catch (e) { localStorage.removeItem("donor_phone"); }
  }
  setScreen("donorAuth");
}

async function donorAuthSubmit() {
  const phone = document.getElementById("phoneInput").value.replace(/[^0-9]/g, "");
  if (phone.length < 10) { state.errorMsg = "شماره موبایل معتبر نیست"; render(); return; }
  try {
    const donor = await api("GET", `/api/donors/${phone}`);
    localStorage.setItem("donor_phone", phone);
    state.donor = donor;
    state.donorMessages = await api("GET", `/api/donors/${phone}/messages`);
    setScreen("donorHome");
  } catch (e) {
    state.form = { phone };
    setScreen("donorRegister", false);
  }
}

async function donorRegisterSubmit() {
  const name = document.getElementById("nameInput").value.trim();
  if (name.length < 2) { state.errorMsg = "نام معتبر نیست"; render(); return; }
  try {
    const donor = await api("POST", "/api/donors/register", { phone: state.form.phone, name });
    localStorage.setItem("donor_phone", donor.phone);
    state.donor = donor;
    state.donorMessages = [];
    setScreen("donorHome");
  } catch (e) { state.errorMsg = e.message; render(); }
}

function donorLogoutAction() {
  localStorage.removeItem("donor_phone");
  state.donor = null; state.donorMessages = [];
  setScreen("landing");
}

async function refreshDonorAction() {
  try {
    state.donor = await api("GET", `/api/donors/${state.donor.phone}`);
    state.donorMessages = await api("GET", `/api/donors/${state.donor.phone}/messages`);
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function donorStartVisitAction() {
  if (!state.donor.visits || state.donor.visits.length === 0) await donorCreateVisit("screening");
  else setScreen("donorVisitPick");
}

async function donorCreateVisit(type) {
  try {
    const res = await api("POST", `/api/donors/${state.donor.phone}/visits`, { type });
    state.donor = res.donor;
    state.activeVisitId = res.visit.id;
    setScreen("donorSurvey", true);
  } catch (e) { state.errorMsg = e.message; render(); }
}

function actionSetForm(key, value) {
  state.form[key] = /^[1-5]$/.test(value) ? Number(value) : value;
  render();
}

function actionToggleSymptom(key, value) {
  const arr = state.form[key] || [];
  let next;
  if (value === "هیچ‌کدام") next = ["هیچ‌کدام"];
  else {
    const withoutNone = arr.filter((v) => v !== "هیچ‌کدام");
    next = withoutNone.includes(value) ? withoutNone.filter((v) => v !== value) : [...withoutNone, value];
  }
  state.form[key] = next;
  render();
}

async function donorSubmitSurvey() {
  const notes = document.getElementById("notesInput").value.trim();
  const payload = { ...state.form, notes };
  try {
    const res = await api("POST", `/api/donors/${state.donor.phone}/visits/${state.activeVisitId}/survey`, payload);
    state.donor = res.donor;
    if (res.visit.type === "donation") setScreen("donorImmediateCheck", true);
    else { showToast("ممنون از پاسخ‌هاتون 🌿"); setScreen("donorHome"); }
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function donorSubmitImmediate() {
  try {
    const res = await api("POST", `/api/donors/${state.donor.phone}/visits/${state.activeVisitId}/immediate-check`, {
      symptoms: state.form.symptoms || [], feeling: state.form.feeling,
    });
    state.donor = res.donor;
    const concerning = res.visit.immediateCheck.concerning;
    showToast(concerning ? "لطفاً به کارکنان مرکز اطلاع بدید" : "اهدا با موفقیت ثبت شد 🎉", concerning ? "rose" : "emerald");
    setScreen("donorHome");
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function donorSubmitFollowUp() {
  try {
    const res = await api("POST", `/api/donors/${state.donor.phone}/visits/${state.activeVisitId}/follow-up`, {
      symptoms: state.form.symptoms || [], feeling: state.form.feeling,
    });
    state.donor = res.donor;
    const concerning = res.visit.followUp.concerning;
    showToast(concerning ? "با مرکز تماس بگیرید؛ همکاران در جریان قرار گرفتند" : "خوشحالیم حالتون خوبه 🌿", concerning ? "rose" : "emerald");
    setScreen("donorHome");
  } catch (e) { state.errorMsg = e.message; render(); }
}

/* ============================================================
   اکشن‌های مسیر کارکنان
   ============================================================ */
async function goStaffLoginAction() {
  if (state.staff) await goStaffDashboardAction();
  else setScreen("staffLogin");
}

async function staffLoginSubmit() {
  const username = document.getElementById("staffUsername").value.trim();
  const password = document.getElementById("staffPassword").value;
  try {
    const staff = await api("POST", "/api/auth/login", { username, password });
    state.staff = staff;
    if (staff.mustChangePassword) { state.forcedPasswordChange = true; setScreen("changePassword"); }
    else await goStaffDashboardAction();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function submitChangePassword() {
  const currentPassword = document.getElementById("curPass").value;
  const newPassword = document.getElementById("newPass").value;
  try {
    await api("POST", "/api/auth/change-password", { currentPassword, newPassword });
    state.staff.mustChangePassword = false;
    showToast("رمز عبور با موفقیت تغییر کرد");
    await goStaffDashboardAction();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function staffLogoutAction() {
  try { await api("POST", "/api/auth/logout"); } catch (e) {}
  state.staff = null;
  setScreen("landing");
}

async function loadStaffDashboardData() {
  state.admin.donors = await api("GET", "/api/admin/donors");
}

async function goStaffDashboardAction() {
  try { await loadStaffDashboardData(); setScreen("staffDashboard"); }
  catch (e) { state.staff = null; state.errorMsg = e.message; setScreen("staffLogin"); }
}

async function goStaffSettingsAction() {
  state.admin.settings = await api("GET", "/api/admin/settings");
  setScreen("staffSettings");
}

async function goStaffUsersAction() {
  state.admin.users = await api("GET", "/api/admin/staff");
  setScreen("staffUsers");
}

async function openDonorDetail(phone) {
  try {
    state.admin.selectedDonor = await api("GET", `/api/admin/donors/${phone}`);
    state.admin.selectedMessages = await api("GET", `/api/admin/donors/${phone}/messages`);
    setScreen("staffDonorDetail");
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function actionApproveDonor(phone) {
  try {
    await api("POST", `/api/admin/donors/${phone}/approve`);
    showToast("تایید شد");
    if (state.screen === "staffDonorDetail") state.admin.selectedDonor = await api("GET", `/api/admin/donors/${phone}`);
    else await loadStaffDashboardData();
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function actionSaveOverrides(phone) {
  const gapDays = document.getElementById("ovGapDays").value;
  const rescreen = document.getElementById("ovRescreen").value;
  try {
    await api("PUT", `/api/admin/donors/${phone}/overrides`, {
      minGapHours: gapDays ? Number(gapDays) * 24 : null,
      rescreenMonths: rescreen ? Number(rescreen) : null,
    });
    state.admin.selectedDonor = await api("GET", `/api/admin/donors/${phone}`);
    showToast("ذخیره شد");
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function actionSendMessage(phone) {
  const body = document.getElementById("msgBody").value.trim();
  const appt = document.getElementById("msgAppointment").value;
  if (!body) { state.errorMsg = "متن پیام خالیه"; render(); return; }
  try {
    await api("POST", `/api/admin/donors/${phone}/messages`, {
      body, appointmentDate: appt ? new Date(appt).toISOString() : null,
    });
    state.admin.selectedMessages = await api("GET", `/api/admin/donors/${phone}/messages`);
    showToast("پیام ارسال شد");
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

function actionToggleClosedDay(day) {
  const s = state.admin.settings;
  const idx = s.closedWeekdays.indexOf(day);
  if (idx >= 0) s.closedWeekdays.splice(idx, 1); else s.closedWeekdays.push(day);
  render();
}

async function actionSaveSettings() {
  const payload = {
    centerName: document.getElementById("setCenterName").value.trim(),
    minGapHours: Number(document.getElementById("setGapDays").value) * 24,
    rescreenMonths: Number(document.getElementById("setRescreenMonths").value),
    labWaitMinDays: Number(document.getElementById("setLabMin").value),
    labWaitMaxDays: Number(document.getElementById("setLabMax").value),
    closedWeekdays: state.admin.settings.closedWeekdays,
  };
  try {
    state.admin.settings = await api("PUT", "/api/admin/settings", payload);
    showToast("تنظیمات ذخیره شد");
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function actionAddStaffUser() {
  const username = document.getElementById("newStaffUsername").value.trim();
  const password = document.getElementById("newStaffPassword").value;
  const role = document.getElementById("newStaffRole").value;
  try {
    await api("POST", "/api/admin/staff", { username, password, role });
    state.admin.users = await api("GET", "/api/admin/staff");
    showToast("کارمند اضافه شد");
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

async function actionDeleteStaffUser(id) {
  try {
    await api("DELETE", `/api/admin/staff/${id}`);
    state.admin.users = state.admin.users.filter((u) => u.id !== Number(id));
    render();
  } catch (e) { state.errorMsg = e.message; render(); }
}

/* ============================================================
   دیسپچر کلیک (event delegation)
   ============================================================ */
document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-action]");
  if (!btn || btn.disabled) return;
  const action = btn.dataset.action;
  const data = btn.dataset;
  switch (action) {
    case "goLanding": setScreen("landing"); break;
    case "goDonorAuth": await goDonorAuth(); break;
    case "goStaffLogin": await goStaffLoginAction(); break;
    case "donorAuthSubmit": await donorAuthSubmit(); break;
    case "donorRegisterSubmit": await donorRegisterSubmit(); break;
    case "donorLogout": donorLogoutAction(); break;
    case "refreshDonor": await refreshDonorAction(); break;
    case "donorStartVisit": await donorStartVisitAction(); break;
    case "backToDonorHome": setScreen("donorHome"); break;
    case "donorCreateVisit": await donorCreateVisit(data.type); break;
    case "openFollowUp": state.activeVisitId = Number(data.visit); setScreen("donorFollowUp", true); break;
    case "setForm": actionSetForm(data.key, data.value); break;
    case "toggleSymptom": actionToggleSymptom(data.key, data.value); break;
    case "donorSubmitSurvey": await donorSubmitSurvey(); break;
    case "donorSubmitImmediate": await donorSubmitImmediate(); break;
    case "donorSubmitFollowUp": await donorSubmitFollowUp(); break;
    case "staffLoginSubmit": await staffLoginSubmit(); break;
    case "staffLogout": await staffLogoutAction(); break;
    case "goChangePassword": state.forcedPasswordChange = false; setScreen("changePassword"); break;
    case "submitChangePassword": await submitChangePassword(); break;
    case "goStaffDashboard": await goStaffDashboardAction(); break;
    case "goStaffSettings": await goStaffSettingsAction(); break;
    case "goStaffUsers": await goStaffUsersAction(); break;
    case "openDonorDetail": await openDonorDetail(data.phone); break;
    case "approveDonor": await actionApproveDonor(data.phone); break;
    case "saveOverrides": await actionSaveOverrides(data.phone); break;
    case "sendMessage": await actionSendMessage(data.phone); break;
    case "saveSettings": await actionSaveSettings(); break;
    case "toggleClosedDay": actionToggleClosedDay(Number(data.day)); break;
    case "addStaffUser": await actionAddStaffUser(); break;
    case "deleteStaffUser": await actionDeleteStaffUser(data.id); break;
  }
});

/* ============================================================
   راه‌اندازی اولیه
   ============================================================ */
(async function init() {
  try { state.publicSettings = await api("GET", "/api/donors/settings/public"); } catch (e) {}
  try { state.staff = await api("GET", "/api/auth/me"); } catch (e) { state.staff = null; }
  render();
})();
