/**
 * استفاده روی خود سرور (مثلاً از طریق Shell سرویس هاست):
 *   node scripts/create-admin.js نام‌کاربری رمزعبور
 *
 * اگه کاربری با همین نام از قبل وجود داشته باشه، رمزش رو بازنشانی می‌کنه.
 */
const bcrypt = require("bcryptjs");
const { mutate } = require("../src/db");

const [, , username, password] = process.argv;

if (!username || !password || password.length < 8) {
  console.error("استفاده: node scripts/create-admin.js <نام‌کاربری> <رمزعبور حداقل ۸ کاراکتر>");
  process.exit(1);
}

mutate((db) => {
  const existing = db.staff.find((s) => s.username === username);
  const passwordHash = bcrypt.hashSync(password, 12);
  if (existing) {
    existing.passwordHash = passwordHash;
    existing.role = "admin";
    existing.mustChangePassword = true;
    console.log(`رمز کاربر «${username}» بازنشانی شد.`);
  } else {
    db.staff.push({
      id: db.nextIds.staff++,
      username,
      passwordHash,
      role: "admin",
      mustChangePassword: true,
      createdAt: new Date().toISOString(),
    });
    console.log(`حساب مدیر «${username}» ساخته شد.`);
  }
});
